wget https://raw.githubusercontent.com/ClarkGuilty/2017/master/metodos/tareas/tarea2/heat_content_index.txt

wget https://raw.githubusercontent.com/ClarkGuilty/2017/master/metodos/tareas/tarea2/SOI.txt 

mkdir Dir_PacificoSur

mv heat_content_index.txt Dir_PacificoSur

mv SOI.txt Dir_PacificoSur

cp PCA_PacificoSur.py Dir_PacificoSur

cd Dir_PacificoSur

python PCA_PacificoSur.py





















