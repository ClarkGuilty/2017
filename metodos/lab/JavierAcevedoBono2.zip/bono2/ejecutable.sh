cc decaimiento.c -lm -o decaimiento.x
./decaimiento.x
cp data.txt
python grafica.py

